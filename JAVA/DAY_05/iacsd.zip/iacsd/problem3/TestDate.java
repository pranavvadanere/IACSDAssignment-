package com.iacsd.problem3;

public class TestDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date date1 = new Date();
		date1.printDate();
		Date date2 = new Date(30, 5, 1995);
		date2.printDate();
	}

}
